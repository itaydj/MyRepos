# -*- coding: utf-8 -*-
#------------------------------------------------------------
# The discjockey Addon by Holyman
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: Holyman
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.discjockey'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "BlackHoleRecordings"
YOUTUBE_CHANNEL_ID_2 = "anacriadomusic"
YOUTUBE_CHANNEL_ID_3 = "RazNitzanMusic"
YOUTUBE_CHANNEL_ID_4 = "armadamusic"
YOUTUBE_CHANNEL_ID_5 = "asotrecordings"
YOUTUBE_CHANNEL_ID_6 = "arminvanbuuren"
YOUTUBE_CHANNEL_ID_7 = "SpinninRec"
YOUTUBE_CHANNEL_ID_8 = "BlackHoleRecordings"
YOUTUBE_CHANNEL_ID_9 = "DashBerlinChannel"
YOUTUBE_CHANNEL_ID_10 = "armadaclassics"
YOUTUBE_CHANNEL_ID_11 = "PureBlissVocalsMusic"
YOUTUBE_CHANNEL_ID_12 = "AmsterdamTranceRadio"
YOUTUBE_CHANNEL_ID_13 = "suandamusic"
YOUTUBE_CHANNEL_ID_14 = "ElectroDanceMovement"
YOUTUBE_CHANNEL_ID_15 = "steveaoki"
YOUTUBE_CHANNEL_ID_16 = "davidguettavevo"
YOUTUBE_CHANNEL_ID_17 = "UMFTV"
YOUTUBE_CHANNEL_ID_18 = "FlashoverRecordings"
YOUTUBE_CHANNEL_ID_19 = "ElectroBootlegMusic"
YOUTUBE_CHANNEL_ID_20 = "SpectrumRecordings"

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="BlackHoleRecordings",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://yt3.ggpht.com/-jhRIq1c5giU/AAAAAAAAAAI/AAAAAAAAAAA/PS5ETqkp8IQ/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="anacriadomusic",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://i.ytimg.com/i/Iv8Eyioau9MGptwNFz0ZVA/mq1.jpg?v=563a3846",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="RazNitzanMusic",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://i.ytimg.com/i/soHXOnM64WwLccxTgwQ-KQ/mq1.jpg?v=5367fddc",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="armadamusic",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://yt3.ggpht.com/-dEX9_a5fWFQ/AAAAAAAAAAI/AAAAAAAAAAA/mobfUQ8WFBU/s100-c-k-no-mo/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="asotrecordings",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://yt3.ggpht.com/-mvO0kwooOtU/AAAAAAAAAAI/AAAAAAAAAAA/19if2KN3_cA/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="arminvanbuuren",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://yt3.ggpht.com/-bp-G-1ubrMA/AAAAAAAAAAI/AAAAAAAAAAA/lysFIFc6AaQ/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="SpinninRec",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://yt3.ggpht.com/-yZkhExtYPZg/AAAAAAAAAAI/AAAAAAAAAAA/OfongtErwyo/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BlackHoleRecordings",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://yt3.ggpht.com/-jhRIq1c5giU/AAAAAAAAAAI/AAAAAAAAAAA/PS5ETqkp8IQ/s100-c-k-no/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="DashBerlinChannel",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://yt3.ggpht.com/-MxzVfcm0bAM/AAAAAAAAAAI/AAAAAAAAAAA/7eAN4ocunoI/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="armadaclassics",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://yt3.ggpht.com/-dWElh0vqQZo/AAAAAAAAAAI/AAAAAAAAAAA/vM1JEPcK9TA/s100-c-k-no/photo.jpg",
        folder=True )                

    plugintools.add_item( 
        #action="", 
        title="PureBlissVocalsMusic",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://yt3.ggpht.com/-Oyv4R89cvsM/AAAAAAAAAAI/AAAAAAAAAAA/N_bN84XM6mk/s100-c-k-no/photo.jpg",
        folder=True )    

    plugintools.add_item( 
        #action="", 
        title="AmsterdamTranceRadio",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://yt3.ggpht.com/-JzY51oLACqs/AAAAAAAAAAI/AAAAAAAAAAA/8vaeyPrOoHM/s100-c-k-no/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="suandamusic",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://yt3.ggpht.com/-R6Pzz4lM5kU/AAAAAAAAAAI/AAAAAAAAAAA/Zg1aQIHAI08/s100-c-k-no/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="ElectroDanceMovement",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://yt3.ggpht.com/-rnymhxYBlaU/AAAAAAAAAAI/AAAAAAAAAAA/ECz2jWvUodA/s100-c-k-no/photo.jpg",
        folder=True ) 
		
    plugintools.add_item( 
        #action="", 
        title="steveaoki",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://yt3.ggpht.com/-klQZylVYFOI/AAAAAAAAAAI/AAAAAAAAAAA/T2luME-Ha6k/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="davidguettavevo",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://yt3.ggpht.com/-p2VTrltKNWw/AAAAAAAAAAI/AAAAAAAAAAA/FkJ2SyyrUMA/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="UMFTV",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://yt3.ggpht.com/-rKgui42bd-0/AAAAAAAAAAI/AAAAAAAAAAA/P0kN8hLuwh0/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="FlashoverRecordings",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="https://yt3.ggpht.com/-HCq9KLzff2g/AAAAAAAAAAI/AAAAAAAAAAA/3rWC_vPaI00/s100-c-k-no/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="ElectroBootlegMusic",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="https://yt3.ggpht.com/-82LIxPb-cx0/AAAAAAAAAAI/AAAAAAAAAAA/BPcD-kwKrSo/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="SpectrumRecordings",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="https://yt3.ggpht.com/-vzLxO7i5Qgk/AAAAAAAAAAI/AAAAAAAAAAA/NvJaOyJCRGE/s100-c-k-no/photo.jpg",
        folder=True )   		
run()
